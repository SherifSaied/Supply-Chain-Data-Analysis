SELECT TABLE_NAME 
FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_TYPE = 'BASE TABLE';
SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
ORDER BY TABLE_NAME, COLUMN_NAME;
SELECT customerFullName, customerCity, customerState
FROM customers;
SELECT customerSegment, COUNT(*) AS NumberOfCustomers
FROM customers
GROUP BY customerSegment;
SELECT orderCustomerId, COUNT(orderId) AS TotalOrders
FROM orders
GROUP BY orderCustomerId;
SELECT productName, productPrice
FROM product;
SELECT orderId, orderDate_dateOrders, orderItemTotal
FROM orders
WHERE orderYear = 2018;
SELECT orderYear, SUM(orderItemTotal) AS TotalSales
FROM orders
GROUP BY orderYear;
SELECT shippingMode, COUNT(orderId) AS NumberOfOrders
FROM orders
GROUP BY shippingMode;
SELECT market
FROM market;
SELECT orderId, orderItemDiscount, orderItemDiscountRate
FROM orders
WHERE orderItemDiscount > 0;
SELECT productName, departmentName
FROM product;
SELECT TOP 10 orderCustomerId, COUNT(orderId) AS TotalOrders
FROM orders
GROUP BY orderCustomerId
ORDER BY TotalOrders DESC;
SELECT c.customerSegment, SUM(sp.sales) AS TotalSales
FROM customers c
JOIN sales_profitt sp ON c.customerKey = sp.customerKey
GROUP BY c.customerSegment;
SELECT m.market, AVG(sp.sales) AS AvgSales
FROM market m
JOIN sales_profitt sp ON m.marketKey = sp.marketKey
GROUP BY m.market;
SELECT customerCountry, COUNT(customerId) AS TotalCustomers
FROM customers
GROUP BY customerCountry;
SELECT p.productName, SUM(o.orderItemQty) AS TotalQuantity
FROM product p
JOIN orders o ON p.productCardId = o.orderItemCardProdId
GROUP BY p.productName
ORDER BY TotalQuantity DESC;
SELECT TOP 5 m.market, SUM(sp.profitPerOrder) AS TotalProfit
FROM market m
JOIN sales_profitt sp ON m.marketKey = sp.marketKey
GROUP BY m.market
ORDER BY TotalProfit DESC;
SELECT orderCountry, COUNT(orderId) AS NumberOfOrders
FROM orders
GROUP BY orderCountry;
SELECT c.customerFullName, COUNT(s.shippingKey) AS LateDeliveries
FROM customers c
JOIN sales_profitt sp ON c.customerKey = sp.customerKey
JOIN shippingg s ON sp.shippingKey = s.shippingKey
WHERE s.lateDeliveryRisk = 1
GROUP BY c.customerFullName
ORDER BY LateDeliveries DESC;
SELECT c.customerSegment, SUM(sp.profitPerOrder) AS TotalProfit
FROM customers c
JOIN sales_profitt sp ON c.customerKey = sp.customerKey
GROUP BY c.customerSegment;
SELECT departmentName, COUNT(productKey) AS TotalProducts
FROM product
GROUP BY departmentName;
WITH ProductCount AS (
    SELECT 
        departmentName, 
        COUNT(productKey) AS TotalProducts
    FROM product
    GROUP BY departmentName
)
SELECT 
    departmentName, 
    TotalProducts
FROM ProductCount
WHERE TotalProducts = (SELECT MAX(TotalProducts) FROM ProductCount)
   OR TotalProducts = (SELECT MIN(TotalProducts) FROM ProductCount);
SELECT AVG(DaysOfShipping_real) AS AvgDeliveryTime
FROM shippingg;
SELECT orderKey, DeliveryStatus, lateDeliveryRisk
FROM shippingg
WHERE DeliveryStatus = 'Late';
SELECT year, COUNT(orderKey) AS LateDeliveries
FROM shippingg
WHERE lateDeliveryRisk = 1
GROUP BY year;
SELECT orderKey, DaysOfShipping_scheduled, DaysOfShipping_real, DeliveryDifference
FROM shippingg;
SELECT shippingDay, COUNT(orderKey) AS NumberOfOrders
FROM orders
GROUP BY shippingDay
ORDER BY NumberOfOrders DESC;
SELECT p.productName, SUM(sp.profitPerOrder) AS TotalProfit
FROM product p
JOIN sales_profitt sp ON p.productKey = sp.productKey
GROUP BY p.productName;
WITH ProfitSummary AS (
    SELECT 
        p.productName, 
        SUM(sp.profitPerOrder) AS TotalProfit
    FROM product p
    JOIN sales_profitt sp ON p.productKey = sp.productKey
    GROUP BY p.productName
)
SELECT 
    productName, 
    TotalProfit
FROM ProfitSummary
WHERE TotalProfit = (SELECT MAX(TotalProfit) FROM ProfitSummary)
   OR TotalProfit = (SELECT MIN(TotalProfit) FROM ProfitSummary);
SELECT p.productName, SUM(sp.profitPerOrder) AS TotalProfit
FROM product p
JOIN sales_profitt sp ON p.productKey = sp.productKey
GROUP BY p.productName
ORDER BY TotalProfit DESC
SELECT p.productName, SUM(sp.profitPerOrder) AS TotalProfit
FROM product p
JOIN sales_profitt sp ON p.productKey = sp.productKey
GROUP BY p.productName
ORDER BY TotalProfit ASC
SELECT TOP 1 p.productName, SUM(sp.profitPerOrder) AS TotalProfit
FROM product p
JOIN sales_profitt sp ON p.productKey = sp.productKey
GROUP BY p.productName
ORDER BY TotalProfit DESC;
SELECT TOP 1 p.productName, SUM(sp.profitPerOrder) AS TotalProfit
FROM product p
JOIN sales_profitt sp ON p.productKey = sp.productKey
GROUP BY p.productName
ORDER BY TotalProfit ASC;
SELECT m.market, AVG(sp.profitMargin) AS AvgProfitMargin
FROM market m
JOIN sales_profitt sp ON m.marketKey = sp.marketKey
GROUP BY m.market;
SELECT o.orderItemQty, sp.profitPerOrder
FROM orders o
JOIN sales_profitt sp ON o.orderKey = sp.orderKey;
WITH Stats AS (
    SELECT 
        COUNT(*) AS N,  -- Number of rows
        SUM(CAST(o.orderItemQty AS BIGINT)) AS Sum_X,  -- Sum of order quantities
        SUM(CAST(sp.profitPerOrder AS FLOAT)) AS Sum_Y,  -- Sum of profits
        SUM(CAST(o.orderItemQty AS BIGINT) * CAST(sp.profitPerOrder AS FLOAT)) AS Sum_XY,  -- Sum of X * Y
        SUM(CAST(o.orderItemQty AS BIGINT) * CAST(o.orderItemQty AS BIGINT)) AS Sum_X2,  -- Sum of X^2
        SUM(CAST(sp.profitPerOrder AS FLOAT) * CAST(sp.profitPerOrder AS FLOAT)) AS Sum_Y2  -- Sum of Y^2
    FROM orders o
    JOIN sales_profitt sp ON o.orderKey = sp.orderKey
)
SELECT 
    (N * Sum_XY - Sum_X * Sum_Y) / 
    SQRT((N * Sum_X2 - Sum_X * Sum_X) * (N * Sum_Y2 - Sum_Y * Sum_Y)) AS PearsonCorrelation
FROM Stats;
SELECT 
    s.DeliveryStatus, SUM(sp.profitPerOrder) AS TotalProfit
FROM shippingg s
JOIN sales_profitt sp ON s.orderKey = sp.orderKey
GROUP BY s.DeliveryStatus;
SELECT 
    s.DeliveryStatus, 
    SUM(sp.profitPerOrder) AS TotalProfit
FROM shippingg s
JOIN sales_profitt sp ON s.shippingKey = sp.shippingKey
GROUP BY s.DeliveryStatus
ORDER BY TotalProfit DESC;
SELECT paymentType, COUNT(orderKey) AS NumberOfOrders, SUM(profitPerOrder) AS TotalProfit
FROM sales_profitt
GROUP BY paymentType;
SELECT 
    paymentType, 
    COUNT(orderKey) AS NumberOfOrders, 
    SUM(profitPerOrder) AS TotalProfit
FROM sales_profitt
GROUP BY paymentType
ORDER BY TotalProfit DESC;
SELECT 
    orderYear, 
    SUM(sp.sales) AS TotalSales
FROM sales_profitt sp
JOIN orders o ON sp.orderKey = o.orderKey
GROUP BY orderYear
ORDER BY TotalSales DESC;
SELECT 
    orderYear, 
    SUM(orderItemTotal) AS TotalSales
FROM orders
GROUP BY orderYear
ORDER BY TotalSales DESC;
SELECT 
    o.orderYear, 
    SUM(sp.sales) AS TotalSales
FROM orders o
JOIN sales_profitt sp ON o.orderKey = sp.orderKey
GROUP BY o.orderYear
ORDER BY TotalSales DESC;
SELECT 
    orderCountry, 
    COUNT(orderId) AS NumberOfOrders
FROM orders
GROUP BY orderCountry
ORDER BY NumberOfOrders DESC;
SELECT p.productName, COUNT(s.orderKey) AS LateDeliveries
FROM product p
JOIN orders o ON p.productCardId = o.orderItemCardProdId
JOIN shippingg s ON o.orderKey = s.orderKey
WHERE s.DeliveryStatus = 'Late'
GROUP BY p.productName
ORDER BY LateDeliveries DESC;
SELECT o.orderRegion, COUNT(s.orderKey) AS LateDeliveries
FROM orders o
JOIN shippingg s ON o.orderKey = s.orderKey
WHERE s.DeliveryStatus = 'Late'
GROUP BY o.orderRegion
ORDER BY LateDeliveries DESC;
SELECT o.shippingMode, COUNT(s.orderKey) AS LateDeliveries
FROM orders o
JOIN shippingg s ON o.orderKey = s.orderKey
WHERE s.DeliveryStatus = 'Late'
GROUP BY o.shippingMode
ORDER BY LateDeliveries DESC;
SELECT productCardId, COUNT(*) 
FROM product
GROUP BY productCardId
HAVING COUNT(*) > 1;
SELECT productCardId, productName, COUNT(*)
FROM product
GROUP BY productCardId, productName
HAVING COUNT(*) > 1;
SELECT orderItemCardProdId, COUNT(*)
FROM orders
GROUP BY orderItemCardProdId
HAVING COUNT(*) > 1;
SELECT p.productName, COUNT(s.orderKey) AS LateDeliveries
FROM product p
JOIN orders o ON p.productCardId = o.orderItemCardProdId
JOIN shippingg s ON o.orderKey = s.orderKey
WHERE s.DeliveryStatus = 'Late'
GROUP BY p.productName
ORDER BY LateDeliveries DESC;
SELECT s.day AS ShippingDay, COUNT(s.orderKey) AS LateDeliveries
FROM shippingg s
WHERE s.DeliveryStatus = 'Late'
GROUP BY s.day
ORDER BY LateDeliveries DESC;
SELECT p.departmentName, AVG(s.DeliveryDifference) AS AvgDelay
FROM product p
JOIN orders o ON p.productCardId = o.orderItemCardProdId
JOIN shippingg s ON o.orderKey = s.orderKey
WHERE s.DeliveryStatus = 'Late'
GROUP BY p.departmentName
ORDER BY AvgDelay DESC;
SELECT 
    p.departmentName, 
    AVG(s.DeliveryDifference) AS AvgDelay
FROM product p
JOIN orders o ON p.productCardId = o.orderItemCardProdId
JOIN shippingg s ON o.orderKey = s.orderKey
WHERE s.DeliveryStatus = 'Late'
  AND s.DeliveryDifference >= 0 
GROUP BY p.departmentName
ORDER BY AvgDelay DESC;
SELECT 
    CASE 
        WHEN s.DeliveryStatus = 'Late' THEN 'Late'
        ELSE 'On Time'
    END AS DeliveryStatus,
    AVG(o.orderItemTotal) AS AvgOrderValue
FROM orders o
JOIN shippingg s ON o.orderKey = s.orderKey
GROUP BY 
    CASE 
        WHEN s.DeliveryStatus = 'Late' THEN 'Late'
        ELSE 'On Time'
    END;
SELECT c.customerSegment, COUNT(s.orderKey) AS LateDeliveries
FROM customers c
JOIN orders o ON c.customerKey = o.orderCustomerId
JOIN shippingg s ON o.orderKey = s.orderKey
WHERE s.DeliveryStatus = 'Late'
GROUP BY c.customerSegment
ORDER BY LateDeliveries DESC;
SELECT 
    o.orderRegion, 
    o.shippingMode, 
    p.departmentName, 
    COUNT(s.orderKey) AS LateDeliveries
FROM orders o
JOIN shippingg s ON o.orderKey = s.orderKey
JOIN product p ON o.orderItemCardProdId = p.productCardId
WHERE s.DeliveryStatus = 'Late'
GROUP BY o.orderRegion, o.shippingMode, p.departmentName
ORDER BY LateDeliveries DESC;
SELECT 
    o.orderId, 
    sp.profitPerOrder, 
    sp.sales, 
    sp.productKey, 
    s.DeliveryStatus
FROM sales_profitt sp
JOIN orders o ON sp.orderKey = o.orderKey
JOIN shippingg s ON o.orderKey = s.orderKey
WHERE sp.profitPerOrder < 0;
SELECT 
    p.productName, 
    p.productPrice, 
    AVG(sp.profitMargin) AS AvgProfitMargin
FROM product p
JOIN sales_profitt sp ON p.productKey = sp.productKey
GROUP BY p.productName, p.productPrice
HAVING AVG(sp.profitMargin) < 0
ORDER BY AvgProfitMargin;
SELECT  
    o.orderId, 
    o.orderItemDiscount, 
    o.orderItemTotal, 
    sp.profitPerOrder
FROM orders o
JOIN sales_profitt sp ON o.orderKey = sp.orderKey
WHERE sp.profitPerOrder < 0
  AND o.orderItemDiscount > 0
ORDER BY sp.profitPerOrder ASC;
SELECT  
    o.orderId, 
    o.orderStatus, 
    o.orderItemDiscount, 
    sp.profitPerOrder, 
    o.orderItemTotal
FROM orders o
JOIN sales_profitt sp ON o.orderKey = sp.orderKey
WHERE o.orderItemTotal IS NULL;
SELECT 
    o.orderStatus, 
    COUNT(*) AS NumberOfOrders
FROM orders o
WHERE o.orderItemTotal IS NULL
GROUP BY o.orderStatus;
SELECT 
    o.orderStatus, 
    SUM(sp.profitPerOrder) AS TotalProfitLoss
FROM orders o
JOIN sales_profitt sp ON o.orderKey = sp.orderKey
WHERE o.orderItemTotal IS NULL
GROUP BY o.orderStatus;
SELECT customerCountry, 
       AVG(DaysOfShipping_real) AS avg_delivery_time
FROM customers 
JOIN shippingg ON customers.customerKey = shippingg.shippingKey
GROUP BY customerCountry
ORDER BY avg_delivery_time DESC;
SELECT market.market, 
       COUNT(CASE WHEN shippingg.lateDeliveryRisk = 1 THEN 1 END) * 100.0 / COUNT(*) AS late_delivery_percentage
FROM shippingg
JOIN sales_profitt ON shippingg.shippingKey = sales_profitt.shippingKey
JOIN market ON sales_profitt.marketKey = market.marketKey
GROUP BY market.market
ORDER BY late_delivery_percentage DESC;
SELECT c.customerCountry, 
       AVG(sg.DaysOfShipping_real) AS avg_delivery_time
FROM customers c
JOIN orders o ON c.customerKey = o.orderCustomerId
JOIN shippingg sg ON o.orderId = sg.orderKey
GROUP BY c.customerCountry
ORDER BY avg_delivery_time DESC;
SELECT TOP 10 *
FROM orders o
JOIN customers c ON o.orderCustomerId = c.customerKey
JOIN shippingg sg ON o.orderId = sg.orderKey;
SELECT 
    c.customerCountry, 
    AVG(CAST(sg.DaysOfShipping_real AS FLOAT)) AS avg_delivery_time
FROM 
    customers c
JOIN 
    orders o ON c.customerKey = o.orderCustomerId
JOIN 
    shippingg sg ON o.orderId = sg.orderKey
WHERE 
    sg.DaysOfShipping_real > 0  -- Ensure no negative or missing values
GROUP BY 
    c.customerCountry
ORDER BY 
    avg_delivery_time DESC;
SELECT 
    productName, 
    COUNT(orderItemId) AS purchase_count
FROM 
    orders o
JOIN 
    product p ON o.orderItemCardProdId = p.productCardId
GROUP BY 
    productName
ORDER BY 
    purchase_count DESC
SELECT 
    p.productName, 
    COUNT(o.orderItemId) AS purchase_count
FROM 
    orders o
JOIN 
    product p ON o.orderItemCardProdId = p.productCardId
GROUP BY 
    p.productName
ORDER BY 
    purchase_count DESC
SELECT 
    c.customerFullName, 
    c.customerSegment,
    p.productName, 
    COUNT(o.orderItemId) AS purchase_count
FROM 
    orders o
JOIN 
    product p ON o.orderItemCardProdId = p.productCardId
JOIN 
    customers c ON o.orderCustomerId = c.customerId
GROUP BY 
    c.customerFullName, c.customerSegment, p.productName
ORDER BY 
    purchase_count DESC

SELECT 
    AVG(CAST(DATEDIFF(day, o.orderDate_dateOrders, s.DaysOfShipping_real) AS FLOAT)) AS avg_delivery_time
FROM 
    orders o
JOIN 
    shippingg s ON o.orderKey = s.orderKey
WHERE 
    s.DeliveryStatus = 'Completed';
	SELECT 
    AVG(CAST(s.DaysOfShipping_real AS FLOAT)) AS avg_delivery_time
FROM 
    orders o
JOIN 
    shippingg s ON o.orderKey = s.orderKey;

SELECT 
    COUNT(*) AS late_orders
FROM 
    orders o
JOIN 
    shippingg s ON o.orderKey = s.orderKey
WHERE 
    s.lateDeliveryRisk = 1;
SELECT 
    COUNT(*) AS late_orders
FROM 
    orders o
JOIN 
    shippingg s ON o.orderKey = s.orderKey
WHERE 
    s.lateDeliveryRisk = 1;
SELECT 
    COUNT(*) AS late_orders
FROM 
    orders o
JOIN 
    shippingg s ON o.orderKey = s.orderKey
WHERE 
    s.DeliveryStatus = 'Late';

	SELECT 
    orderRegion, 
    COUNT(orderId) AS total_orders
FROM 
    orders
GROUP BY 
    orderRegion
ORDER BY 
    total_orders DESC;


	SELECT 
    o.orderRegion, 
    m.market, 
    COUNT(o.orderId) AS total_orders
FROM 
    orders o
JOIN 
    market m ON o.orderId = m.marketKey
GROUP BY 
    o.orderRegion, m.market
ORDER BY 
    total_orders DESC;


	SELECT *
FROM shippingg

SELECT 
    shippingMode, 
    COUNT(*) AS total_orders
FROM 
    orders
GROUP BY 
    shippingMode
ORDER BY 
    total_orders DESC;


	SELECT 
    (COUNT(CASE WHEN orderStatus = 'SUSPECTED_FRAUD' THEN 1 ELSE NULL END) * 100.0) / COUNT(*) AS fraud_percentage
FROM 
    orders;

	SELECT 
    c.customerSegment, 
    SUM(o.orderItemTotal) AS total_sales
FROM 
    orders o
JOIN 
    customers c ON o.orderCustomerId = c.customerId
GROUP BY 
    c.customerSegment
ORDER BY 
    total_sales DESC;


	SELECT 
    c.customerSegment, 
    SUM(
        TRY_CAST(o.orderItemTotal AS FLOAT) - 
        (TRY_CAST(o.orderItemTotal AS FLOAT) * TRY_CAST(o.orderItemDiscountRate AS FLOAT))
    ) AS total_sales_after_discount
FROM 
    orders o
JOIN 
    customers c ON o.orderCustomerId = c.customerId
GROUP BY 
    c.customerSegment
HAVING SUM(TRY_CAST(o.orderItemTotal AS FLOAT)) > 0
ORDER BY 
    total_sales_after_discount DESC;



SELECT 
    c.customerSegment, 
    SUM(
        TRY_CAST(o.orderItemTotal AS FLOAT) - 
        (TRY_CAST(o.orderItemTotal AS FLOAT) * TRY_CAST(o.orderItemDiscountRate AS FLOAT))
    ) AS total_sales_after_discount
FROM 
    orders o
JOIN 
    customers c ON o.orderCustomerId = c.customerId
WHERE 
    TRY_CAST(o.orderItemTotal AS FLOAT) IS NOT NULL 
    AND TRY_CAST(o.orderItemDiscountRate AS FLOAT) IS NOT NULL
GROUP BY 
    c.customerSegment
ORDER BY 
    total_sales_after_discount DESC;



	WITH segment_sales AS (
    SELECT 
        c.customerSegment, 
        SUM(o.orderItemTotal) AS total_sales
    FROM 
        orders o
    JOIN 
        customers c ON o.orderCustomerId = c.customerId
    GROUP BY 
        c.customerSegment
)
SELECT 
    customerSegment, 
    total_sales, 
    ROUND((total_sales * 100.0) / (SELECT SUM(total_sales) FROM segment_sales), 2) AS sales_percentage
FROM 
    segment_sales
ORDER BY 
    total_sales DESC;



SELECT 
    COUNT(CASE WHEN orderItemDiscount > 0 THEN 1 END) AS discounted_orders,
    COUNT(*) AS total_orders,
    ROUND((COUNT(CASE WHEN orderItemDiscount > 0 THEN 1 END) * 100.0) / COUNT(*), 2) AS discount_percentage
FROM 
    orders
WHERE 
    orderItemDiscount IS NOT NULL;




SELECT 
    c.customerCity, 
    SUM(o.orderItemTotal) AS total_sales_revenue
FROM 
    orders o
JOIN 
    customers c ON o.orderCustomerId = c.customerId
WHERE 
    o.orderItemTotal IS NOT NULL
GROUP BY 
    c.customerCity
ORDER BY 
    total_sales_revenue DESC;



	
SELECT *
FROM shippingg



WITH delivery_analysis AS (
    SELECT 
        s.[orderKey] AS orderId, 
        s.[DaysOfShipping_real] AS delivery_time, 
        s.[lateDeliveryRisk]
    FROM 
        shippingg s
    WHERE 
        s.[DaysOfShipping_real] IS NOT NULL
)
SELECT 
    lateDeliveryRisk, 
    AVG(CAST(delivery_time AS FLOAT)) AS avg_delivery_time, 
    COUNT(orderId) AS total_orders
FROM 
    delivery_analysis
GROUP BY 
    lateDeliveryRisk;





WITH product_profit_margin AS (
    SELECT 
        p.[productName], 
        p.[productPrice], 
        SUM(sp.[profitPerOrder]) AS total_profit,
        SUM(sp.[profitPerOrder]) / NULLIF(SUM(p.[productPrice] * o.[orderItemQty]), 0) AS profit_margin
    FROM 
        product p
    JOIN 
        orders o ON p.[productKey] = o.[orderItemCardProdId]
    JOIN 
        sales_profitt sp ON o.[orderId] = sp.[orderKey]
    WHERE 
        p.[productPrice] IS NOT NULL 
        AND sp.[profitPerOrder] IS NOT NULL
    GROUP BY 
        p.[productName], p.[productPrice]
)
SELECT 
    productName, 
    ROUND(profit_margin * 100, 2) AS profit_margin_percentage, 
    total_profit
FROM 
    product_profit_margin
ORDER BY 
    profit_margin_percentage DESC;
















WITH customer_segment_analysis AS (
    SELECT 
        c.[customerSegment], 
        SUM(CASE WHEN o.[orderStatus] = 'CANCELED' THEN 1 ELSE 0 END) AS canceled_orders,
        SUM(CASE WHEN o.[orderStatus] = 'SUSPECTED_FRAUD' THEN 1 ELSE 0 END) AS fraud_orders,
        COUNT(o.[orderId]) AS total_orders
    FROM 
        customers c
    JOIN 
        orders o ON c.[customerId] = o.[orderCustomerId]
    GROUP BY 
        c.[customerSegment]
)
SELECT 
    customerSegment,
    canceled_orders,
    fraud_orders,
    total_orders,
    ROUND((canceled_orders * 100.0) / NULLIF(total_orders, 0), 2) AS cancellation_rate,
    ROUND((fraud_orders * 100.0) / NULLIF(total_orders, 0), 2) AS fraud_rate
FROM 
    customer_segment_analysis
ORDER BY 
    fraud_rate DESC






WITH shipping_profit_analysis AS (
    SELECT 
        s.[lateDeliveryRisk], 
        SUM(p.[profitPerOrder]) AS total_profit,
        COUNT(o.[orderId]) AS total_orders
    FROM 
        orders o
    JOIN 
        shippingg s ON o.[orderId] = s.[orderKey]
    JOIN 
        sales_profitt p ON o.[orderId] = p.[orderKey]
    WHERE 
        p.[profitPerOrder] IS NOT NULL
    GROUP BY 
        s.[lateDeliveryRisk]
)
SELECT 
    lateDeliveryRisk,
    total_orders,
    total_profit,
    ROUND((total_profit * 1.0) / NULLIF(total_orders, 0), 2) AS avg_profit_per_order
FROM 
    shipping_profit_analysis
ORDER BY 
    avg_profit_per_order DESC;


	WITH shipping_profit_analysis AS (
    SELECT 
        s.[lateDeliveryRisk], 
        SUM(p.[profitPerOrder]) AS total_profit,
        COUNT(o.[orderId]) AS total_orders
    FROM 
        orders o
    JOIN 
        shippingg s ON o.[orderId] = s.[orderKey]
    JOIN 
        sales_profitt p ON o.[orderId] = p.[orderKey]
    WHERE 
        p.[profitPerOrder] IS NOT NULL
    GROUP BY 
        s.[lateDeliveryRisk]
)
SELECT 
    lateDeliveryRisk AS "Shipping Delay Risk",
    total_orders AS "Total Orders",
    total_profit AS "Total Profit",
    ROUND((total_profit * 1.0) / NULLIF(total_orders, 0), 2) AS "Avg Profit per Order"
FROM 
    shipping_profit_analysis
ORDER BY 
    "Avg Profit per Order" DESC;





















SELECT 
    o.orderId, 
    o.orderRegion, 
    s.DaysOfShipping_real, 
    s.DaysOfShipping_scheduled, 
    (s.DaysOfShipping_real - s.DaysOfShipping_scheduled) AS shipping_variance
FROM 
    orders o
JOIN 
    shippingg s ON o.orderId = s.orderKey
WHERE 
    s.DaysOfShipping_real IS NOT NULL 
    AND s.DaysOfShipping_scheduled IS NOT NULL
ORDER BY 
    shipping_variance DESC;





SELECT 
    o.orderRegion, 
    AVG(CAST(s.DaysOfShipping_real - s.DaysOfShipping_scheduled AS FLOAT)) AS avg_shipping_variance,
    COUNT(o.orderId) AS total_orders
FROM 
    orders o
JOIN 
    shippingg s ON o.orderId = s.orderKey
WHERE 
    s.DaysOfShipping_real IS NOT NULL 
    AND s.DaysOfShipping_scheduled IS NOT NULL
GROUP BY 
    o.orderRegion
ORDER BY 
    avg_shipping_variance DESC;














SELECT 
    o.orderRegion, 
    COUNT(CASE 
        WHEN (s.DaysOfShipping_real - s.DaysOfShipping_scheduled) != 0 
        THEN 1 
        ELSE NULL 
    END) AS variance_count,
    COUNT(o.orderId) AS total_orders,
    ROUND((COUNT(CASE 
        WHEN (s.DaysOfShipping_real - s.DaysOfShipping_scheduled) != 0 
        THEN 1 
        ELSE NULL 
    END) * 100.0) / COUNT(o.orderId), 2) AS variance_percentage
FROM 
    orders o
JOIN 
    shippingg s ON o.orderId = s.orderKey
WHERE 
    s.DaysOfShipping_real IS NOT NULL 
    AND s.DaysOfShipping_scheduled IS NOT NULL
GROUP BY 
    o.orderRegion
ORDER BY 
    variance_count DESC;























SELECT 
    TOP 10 
    orderId, 
    orderItemTotal, 
    orderItemDiscountRate
FROM 
    orders
ORDER BY 
    orderItemTotal DESC;




SELECT 
    TOP 10 
    orderId, 
    orderItemTotal, 
    orderItemDiscountRate
FROM 
    orders
ORDER BY 
    orderItemTotal DESC;















WITH cleaned_orders AS (
    SELECT 
        orderId, 
        orderItemTotal, 
        TRY_CAST(REPLACE(orderItemDiscountRate, '%', '') AS FLOAT) / 100 AS discount_rate
    FROM 
        orders
    WHERE 
        orderItemDiscountRate LIKE '%[0-9]%'  -- Ensure it contains numeric values
),
top_high_value_orders AS (
    SELECT 
        TOP 10 
        orderId, 
        orderItemTotal, 
        discount_rate
    FROM 
        cleaned_orders
    ORDER BY 
        orderItemTotal DESC
)
SELECT 
    AVG(discount_rate) AS avg_discount_rate
FROM 
    top_high_value_orders;
















WITH canceled_orders AS (
    SELECT 
        c.customerCity, 
        c.customerCountry, 
        c.customerSegment, 
        COUNT(o.orderId) AS canceled_orders
    FROM 
        orders o
    JOIN 
        customers c ON o.orderCustomerId = c.customerId
    WHERE 
        o.orderStatus = 'Canceled' 
    GROUP BY 
        c.customerCity, 
        c.customerCountry, 
        c.customerSegment
)
SELECT 
    customerCity, 
    customerCountry, 
    customerSegment, 
    canceled_orders,
    RANK() OVER (ORDER BY canceled_orders DESC) AS rank
FROM 
    canceled_orders
ORDER BY 
    canceled_orders DESC;









WITH order_data AS (
    SELECT 
        orderId,
        SUM(CAST(orderItemQty AS FLOAT)) AS total_items,
        SUM(CAST(orderProfitPerOrder AS FLOAT)) AS total_profit
    FROM 
        orders
    GROUP BY 
        orderId
),
stats AS (
    SELECT 
        COUNT(*) AS n,
        SUM(total_items) AS sum_x,
        SUM(total_profit) AS sum_y,
        SUM(total_items * total_profit) AS sum_xy,
        SUM(total_items * total_items) AS sum_xx,
        SUM(total_profit * total_profit) AS sum_yy
    FROM 
        order_data
)
SELECT 
    (n * sum_xy - sum_x * sum_y) / 
    (SQRT(n * sum_xx - sum_x * sum_x) * SQRT(n * sum_yy - sum_y * sum_y)) AS correlation
FROM 
    stats;
















SELECT 
    o.orderRegion AS market,
    AVG(CAST(o.orderItemTotal AS FLOAT) - CAST(sp.profitPerOrder AS FLOAT)) AS avg_refund_or_loss,
    COUNT(o.orderId) AS total_returns_or_refunds
FROM 
    orders o
JOIN 
    sales_profitt sp ON o.orderId = sp.orderKey
WHERE 
    (o.orderItemTotal - sp.profitPerOrder) > 0  -- Identifying orders with potential refunds/losses
GROUP BY 
    o.orderRegion
ORDER BY 
    avg_refund_or_loss DESC;





SELECT 
    o.orderRegion AS market,
    SUM(CAST(o.orderItemTotal AS FLOAT) - CAST(sp.profitPerOrder AS FLOAT)) AS total_refunds_or_loss,
    COUNT(o.orderId) AS total_returned_orders
FROM 
    orders o
JOIN 
    sales_profitt sp ON o.orderId = sp.orderKey
WHERE 
    (o.orderItemTotal - sp.profitPerOrder) > 0  -- Identifying refunded or returned orders
GROUP BY 
    o.orderRegion
ORDER BY 
    total_refunds_or_loss DESC;
